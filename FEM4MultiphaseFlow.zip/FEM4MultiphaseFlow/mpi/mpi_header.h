#ifndef FILE_MPI_HEADER
#define FILE_MPI_HEADER

#include <iostream>
#include <fstream>
#include <iomanip>
#include <stdlib.h>
#include <mpi.h>

#include "mpi_lib.h"

#endif

