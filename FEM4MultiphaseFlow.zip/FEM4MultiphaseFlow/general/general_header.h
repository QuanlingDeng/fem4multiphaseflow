#ifndef FILE_GENERAL_HEADER
#define FILE_GENERAL_HEADER

#include <iostream>
#include <fstream>
#include <iomanip>
#include <stdlib.h>
//#include <omp.h>
#include <cmath>

#include "array.hpp"
#include "trigaussquad.h"
#include "evalfunc.h"
#include "function.h"

#endif
