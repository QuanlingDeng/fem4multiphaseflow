
int sorted_ok (int n, int *p);


void mergesort (int np, int *p, int *aux);


void mergecsrrows (int nr, int *row, int *ii, int *jj,
                   int *merged, int *aux, int *i_merged);
